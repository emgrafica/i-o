import babel from 'rollup-plugin-babel';
import resolve from '@rollup/plugin-node-resolve';
import external from 'rollup-plugin-peer-deps-external';
import { terser } from 'rollup-plugin-terser';
import postcss from 'rollup-plugin-postcss';
import commonjs from '@rollup/plugin-commonjs';
import svg from 'rollup-plugin-svg';
import json from '@rollup/plugin-json';

const path = require('path');

const EXTERNAL = [
  'react',
  'react-dom',
  'prop-types',
];

export default [
    {
        input: './src/index.js',
        output: [
            {
                file: 'dist/index.js',
                format: 'cjs',
            },
            {
                file: 'dist/index.es.js',
                format: 'es',
                exports: 'named',
            }
        ],
        external: EXTERNAL,
        plugins: [
            postcss({
                plugins: [],
                minimize: true,
            }),
            babel({
                exclude: 'node_modules/**',
                presets: ['@babel/preset-react'],
            }),
            commonjs({
                include: 'node_modules/**',
                namedExports: {
                    'node_modules/classnames/index.d.js': ['classNames']
                }
            }),
            external(),
            resolve(),
            terser(),
            resolve({
                alias: {
                    // Needed when library is linked via `npm link` to app
                    react: path.resolve("./node_modules/react")
                }
            }),
            svg(),
            json()
        ]
    }
];