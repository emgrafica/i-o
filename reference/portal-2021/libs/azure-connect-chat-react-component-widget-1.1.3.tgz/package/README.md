# azure-connect-chat-react-component
 Azure Connect Chat using Reactjs based on Azure Bot Framework - Direct Line Channel
