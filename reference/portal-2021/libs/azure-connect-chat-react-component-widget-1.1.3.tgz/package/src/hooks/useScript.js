import { useEffect } from 'react';

const useScript = (url, setIsScriptLoaded) => {
    const scripLoaded = () => {
        // When script loaded, set flag is true 
        if (WEB_UI_CONFIG_EXTERNAL) {
            setIsScriptLoaded(true);
        }
    }
    useEffect(() => {
        const script = document.createElement('script');
        script.src = url;
        script.async = true;
        script.onload = () => scripLoaded();
        document.body.appendChild(script);
        return () => {
            document.body.removeChild(script);
        };
    }, [url]);
};

export default useScript;