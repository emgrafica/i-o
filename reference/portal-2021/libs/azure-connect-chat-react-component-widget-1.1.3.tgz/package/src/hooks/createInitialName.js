const createInitialName = (name) => {
    return name
        .replace(/\b(\w)\w+/g, '$1')
        .replace(/[\s-]/g, '')
        .replace(/\.$/, '')
        .toUpperCase();
}
export default createInitialName;