export default function validateInfo(values) {
    let errors = {};
    if (!values.customUserAttribute4.trim()) {
        errors.customUserAttribute4 = "Problem types is required"
    }

    if (!values.initialMessage.trim()) {
        errors.initialMessage = "Describle is required"
    }

    return errors;
}