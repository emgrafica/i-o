import React, { useState, useEffect } from 'react'
import classNames from 'classnames';
// import logo from '../images/braskem_logo.png';
import './Landing.css';
import validateInfo from '../validationInfo';
import validateInformation from '../validateInformation';

const Landing = (props) => {
    const [errors, setErrors] = useState({});
    const WEB_UI_CONFIG = props.WEB_UI_CONFIG;
    const DEFAULT_LANGUAGE_ID_REF = WEB_UI_CONFIG.languageConfig.defaultLanguageIdRef;
    const [LANDING_CONFIG, SET_LANDING_CONFIG] = useState(WEB_UI_CONFIG.landingConfig);
    const [languageId, setlanguageId] = useState(WEB_UI_CONFIG.languageConfig.supportedLanguages.find(supportedLanguage => supportedLanguage.languageCode === props.userLanguage).languageId)
    const [isValidInfo, setIsValidInfo] = useState();
    // Create state for selected language object and set default value by default language id ref
    const [selectedLanguageIdRef, setSelectedLanguageIdRef] = useState(DEFAULT_LANGUAGE_ID_REF);
    // Create state for object that include ui page information
    const [selectedLanguage, setSelectedLanguage] = useState({
        hideLandingOnStart: LANDING_CONFIG.hideLandingOnStart,

        pageTitle: LANDING_CONFIG.pageTitle.textList.find(pageTitle => pageTitle.languageIdRef === DEFAULT_LANGUAGE_ID_REF).text,
        landingHeaderTitle: LANDING_CONFIG.landingHeaderTitle.textList.find(landingHeaderTitle => landingHeaderTitle.languageIdRef === DEFAULT_LANGUAGE_ID_REF).text,
        landingHeaderTitleText: LANDING_CONFIG.landingHeaderTitleText.textList.find(landingHeaderTitleText => landingHeaderTitleText.languageIdRef === DEFAULT_LANGUAGE_ID_REF).text,
        missingRequirementFieldError: LANDING_CONFIG.missingRequirementFieldError.textList.find(missingRequirementFieldError => missingRequirementFieldError.languageIdRef === DEFAULT_LANGUAGE_ID_REF).text,

        inputlanguageLabel: LANDING_CONFIG.inputlanguageLabel.textList.find(inputlanguageLabel => inputlanguageLabel.languageIdRef === DEFAULT_LANGUAGE_ID_REF).text,

        inputFirstNameEnabled: LANDING_CONFIG.inputFirstNameEnabled,
        inputFirstNameLabel: LANDING_CONFIG.inputFirstNameLabel.textList.find(inputFirstNameLabel => inputFirstNameLabel.languageIdRef === DEFAULT_LANGUAGE_ID_REF).text,
        inputFirstNamePlaceholder: LANDING_CONFIG.inputFirstNamePlaceholder.textList.find(inputFirstNamePlaceholder => inputFirstNamePlaceholder.languageIdRef === DEFAULT_LANGUAGE_ID_REF).text,

        inputEmailEnabled: LANDING_CONFIG.inputEmailEnabled,
        inputEmailLabel: LANDING_CONFIG.inputEmailLabel.textList.find(inputEmailLabel => inputEmailLabel.languageIdRef === DEFAULT_LANGUAGE_ID_REF).text,
        inputEmailPlaceholder: LANDING_CONFIG.inputEmailPlaceholder.textList.find(inputEmailPlaceholder => inputEmailPlaceholder.languageIdRef === DEFAULT_LANGUAGE_ID_REF).text,

        inputCustomAttribute2Enabled: LANDING_CONFIG.inputCustomAttribute2Enabled,
        inputCustomAttribute2Label: LANDING_CONFIG.inputCustomAttribute2Label.textList.find(inputCustomAttribute2Label => inputCustomAttribute2Label.languageIdRef === DEFAULT_LANGUAGE_ID_REF).text,
        inputCustomAttribute2Placeholder: LANDING_CONFIG.inputCustomAttribute2Placeholder.textList.find(inputCustomAttribute2Placeholder => inputCustomAttribute2Placeholder.languageIdRef === DEFAULT_LANGUAGE_ID_REF).text,

        inputCustomAttribute3Enabled: LANDING_CONFIG.inputCustomAttribute3Enabled,
        inputCustomAttribute3Label: LANDING_CONFIG.inputCustomAttribute3Label.textList.find(inputCustomAttribute3Label => inputCustomAttribute3Label.languageIdRef === DEFAULT_LANGUAGE_ID_REF).text,
        inputCustomAttribute3Placeholder: LANDING_CONFIG.inputCustomAttribute3Placeholder.textList.find(inputCustomAttribute3Placeholder => inputCustomAttribute3Placeholder.languageIdRef === DEFAULT_LANGUAGE_ID_REF).text,

        inputCustomAttribute4Enabled: LANDING_CONFIG.inputCustomAttribute4Enabled,
        inputCustomAttribute4Label: LANDING_CONFIG.inputCustomAttribute4Label.textList.find(inputCustomAttribute4Label => inputCustomAttribute4Label.languageIdRef === DEFAULT_LANGUAGE_ID_REF).text,

        inputInitialMessageEnabled: LANDING_CONFIG.inputInitialMessageEnabled,
        inputInitialMessageLabel: LANDING_CONFIG.inputInitialMessageLabel.textList.find(inputInitialMessageLabel => inputInitialMessageLabel.languageIdRef === DEFAULT_LANGUAGE_ID_REF).text,
        inputInitalMessagePlaceholder: LANDING_CONFIG.inputInitalMessagePlaceholder.textList.find(inputInitalMessagePlaceholder => inputInitalMessagePlaceholder.languageIdRef === DEFAULT_LANGUAGE_ID_REF).text,

        buttonStartChatLabel: LANDING_CONFIG.buttonStartChatLabel.textList.find(buttonStartChatLabel => buttonStartChatLabel.languageIdRef === DEFAULT_LANGUAGE_ID_REF).text,

        messageErrorOccurred: LANDING_CONFIG.messageErrorOccurred.textList.find(messageErrorOccurred => messageErrorOccurred.languageIdRef === DEFAULT_LANGUAGE_ID_REF).text,

        messageErrorPleaseEnter: LANDING_CONFIG.messageErrorPleaseEnter.textList.find(messageErrorPleaseEnter => messageErrorPleaseEnter.languageIdRef === DEFAULT_LANGUAGE_ID_REF).text,

        messageErrorInitChat: LANDING_CONFIG.messageErrorInitChat.textList.find(messageErrorInitChat => messageErrorInitChat.languageIdRef === DEFAULT_LANGUAGE_ID_REF).text,
    });

    const [initChatInfo, setInitChatInfo] = useState({
        chatLanguage: props.userLanguage,
        firstName: props.userFirstName,
        emailId: props.userEmail,
        customUserAttribute2: LANDING_CONFIG.inputCustomAttribute2Enabled ? "Required" : "Not required",
        customUserAttribute3: LANDING_CONFIG.inputCustomAttribute3Enabled ? "Required" : "Not required",
        customUserAttribute4: LANDING_CONFIG.inputCustomAttribute4Options[0].value ? LANDING_CONFIG.inputCustomAttribute4Options[0].value : '',
        initialMessage: '',
        languageId: DEFAULT_LANGUAGE_ID_REF
    });

    const handleSubmitLandingPage = (e) => {
        e.preventDefault();
        setErrors(validateInfo(initChatInfo));
        let isValid = validateInformation(initChatInfo);
        setIsValidInfo(isValid);
        if (isValid && initChatInfo.initialMessage !== '') {
            props.setInitChatInfo(initChatInfo);
        }
    }

    const handleChange = (e) => {
        const { name, value } = e.target;
        let prevInfoChat = Object.assign({}, initChatInfo);
        if (name === 'chatLanguage') {
            syncUiConfig(languageId);
            let languageCode = WEB_UI_CONFIG.languageConfig.supportedLanguages.find(supportedLanguage => supportedLanguage.languageId === value).languageCode;
            prevInfoChat['languageId'] = value;
            prevInfoChat[name] = languageCode;
            setInitChatInfo(prevInfoChat);
        }
        else {
            prevInfoChat[name] = value;
            setInitChatInfo(prevInfoChat);
        }
    }

    const syncUiConfig = (languageIdRef) => {
        let uiConfig = {
            hideLandingOnStart: WEB_UI_CONFIG.landingConfig.hideLandingOnStart,

            pageTitle: WEB_UI_CONFIG.landingConfig.pageTitle.textList.find(pageTitle => pageTitle.languageIdRef === languageIdRef).text,
            landingHeaderTitle: WEB_UI_CONFIG.landingConfig.landingHeaderTitle.textList.find(landingHeaderTitle => landingHeaderTitle.languageIdRef === languageIdRef).text,
            landingHeaderTitleText: WEB_UI_CONFIG.landingConfig.landingHeaderTitleText.textList.find(landingHeaderTitleText => landingHeaderTitleText.languageIdRef === languageIdRef).text,
            missingRequirementFieldError: WEB_UI_CONFIG.landingConfig.missingRequirementFieldError.textList.find(missingRequirementFieldError => missingRequirementFieldError.languageIdRef === languageIdRef).text,
            // inputLanguageOptionText: WEB_UI_CONFIG.landingConfig.inputLanguageOptionText.textList.find(inputLanguageOptionText => inputLanguageOptionText.languageIdRef === DEFAULT_LANGUAGE_ID_REF),
            inputlanguageLabel: WEB_UI_CONFIG.landingConfig.inputlanguageLabel.textList.find(inputlanguageLabel => inputlanguageLabel.languageIdRef === languageIdRef).text,

            inputFirstNameEnabled: WEB_UI_CONFIG.landingConfig.inputFirstNameEnabled,
            inputFirstNameLabel: WEB_UI_CONFIG.landingConfig.inputFirstNameLabel.textList.find(inputFirstNameLabel => inputFirstNameLabel.languageIdRef === languageIdRef).text,
            inputFirstNamePlaceholder: WEB_UI_CONFIG.landingConfig.inputFirstNamePlaceholder.textList.find(inputFirstNamePlaceholder => inputFirstNamePlaceholder.languageIdRef === languageIdRef).text,

            inputEmailEnabled: WEB_UI_CONFIG.landingConfig.inputEmailEnabled,
            inputEmailLabel: WEB_UI_CONFIG.landingConfig.inputEmailLabel.textList.find(inputEmailLabel => inputEmailLabel.languageIdRef === languageIdRef).text,
            inputEmailPlaceholder: WEB_UI_CONFIG.landingConfig.inputEmailPlaceholder.textList.find(inputEmailPlaceholder => inputEmailPlaceholder.languageIdRef === languageIdRef).text,

            inputCustomAttribute2Enabled: WEB_UI_CONFIG.landingConfig.inputCustomAttribute2Enabled,
            inputCustomAttribute2Label: WEB_UI_CONFIG.landingConfig.inputCustomAttribute2Label.textList.find(inputCustomAttribute2Label => inputCustomAttribute2Label.languageIdRef === languageIdRef).text,
            inputCustomAttribute2Placeholder: WEB_UI_CONFIG.landingConfig.inputCustomAttribute2Placeholder.textList.find(inputCustomAttribute2Placeholder => inputCustomAttribute2Placeholder.languageIdRef === languageIdRef).text,

            inputCustomAttribute3Enabled: WEB_UI_CONFIG.landingConfig.inputCustomAttribute3Enabled,
            inputCustomAttribute3Label: WEB_UI_CONFIG.landingConfig.inputCustomAttribute3Label.textList.find(inputCustomAttribute3Label => inputCustomAttribute3Label.languageIdRef === languageIdRef).text,
            inputCustomAttribute3Placeholder: WEB_UI_CONFIG.landingConfig.inputCustomAttribute3Placeholder.textList.find(inputCustomAttribute3Placeholder => inputCustomAttribute3Placeholder.languageIdRef === languageIdRef).text,

            inputCustomAttribute4Enabled: WEB_UI_CONFIG.landingConfig.inputCustomAttribute4Enabled,
            inputCustomAttribute4Label: WEB_UI_CONFIG.landingConfig.inputCustomAttribute4Label.textList.find(inputCustomAttribute4Label => inputCustomAttribute4Label.languageIdRef === languageIdRef).text,

            inputInitialMessageEnabled: WEB_UI_CONFIG.landingConfig.inputInitialMessageEnabled,
            inputInitialMessageLabel: WEB_UI_CONFIG.landingConfig.inputInitialMessageLabel.textList.find(inputInitialMessageLabel => inputInitialMessageLabel.languageIdRef === languageIdRef).text,
            inputInitalMessagePlaceholder: WEB_UI_CONFIG.landingConfig.inputInitalMessagePlaceholder.textList.find(inputInitalMessagePlaceholder => inputInitalMessagePlaceholder.languageIdRef === languageIdRef).text,

            buttonStartChatLabel: WEB_UI_CONFIG.landingConfig.buttonStartChatLabel.textList.find(buttonStartChatLabel => buttonStartChatLabel.languageIdRef === languageIdRef).text,

            messageErrorOccurred: WEB_UI_CONFIG.landingConfig.messageErrorOccurred.textList.find(messageErrorOccurred => messageErrorOccurred.languageIdRef === languageIdRef).text,

            messageErrorPleaseEnter: WEB_UI_CONFIG.landingConfig.messageErrorPleaseEnter.textList.find(messageErrorPleaseEnter => messageErrorPleaseEnter.languageIdRef === languageIdRef).text,

            messageErrorInitChat: WEB_UI_CONFIG.landingConfig.messageErrorInitChat.textList.find(messageErrorInitChat => messageErrorInitChat.languageIdRef === languageIdRef).text,
        }
        setSelectedLanguageIdRef(languageIdRef);
        setSelectedLanguage(uiConfig);
    }

    const renderDropDownOptions = (selectedLanguageIdRef) => {
        let options = [];
        let optionSorteds = [];
        for (let i = 0; i < LANDING_CONFIG.inputCustomAttribute4Options.length; i++) {
            let optionTextList = LANDING_CONFIG.inputCustomAttribute4Options[i].optionText.textList;
            let value = LANDING_CONFIG.inputCustomAttribute4Options[i].value;
            let text = optionTextList.find(text => text.languageIdRef === selectedLanguageIdRef).text;
            optionSorteds.push({ value: value, text: text });
        }
        optionSorteds.sort((a, b) => a.text.localeCompare(b.text));
        optionSorteds.forEach(option => {
            options.push(<option key={option.value} value={option.value}>{option.text}</option>);
        });
        return options;
    }
    useEffect(() => {
        let userInfo = Object.assign({}, initChatInfo);
        userInfo['chatLanguage'] = props.userLanguage;
        userInfo['firstName'] = props.userFirstName;
        userInfo['emailId'] = props.userEmail;
        setInitChatInfo(userInfo);
    }, [props]);

    useEffect(() => {
        SET_LANDING_CONFIG(WEB_UI_CONFIG.landingConfig);
        syncUiConfig(languageId);
    }, [props.WEB_UI_CONFIG]);

    return (
        <div className="connect-chat-widget__landing-page">
            <div className="connect-chat-widget__landing-page__chat-letter">
                <h3 className="connect-chat-widget__landing-page__chat-letter__header">{selectedLanguage.landingHeaderTitle}</h3>
                <p className="connect-chat-widget__landing-page__chat-letter__content">{selectedLanguage.landingHeaderTitleText}</p>
            </div>
            {isValidInfo === false && !errors.initChatInfo && (<p className="error-text_not-valid">{selectedLanguage.missingRequirementFieldError}</p>)}
            <form onSubmit={handleSubmitLandingPage}>

                <CustomUserAttribute2Session selectedLanguage={selectedLanguage} handleChange={handleChange} />

                <CustomUserAttribute3Session selectedLanguage={selectedLanguage} handleChange={handleChange} />

                <CustomUserAttribute4Session renderDropDownOptions={renderDropDownOptions(selectedLanguageIdRef)}
                    selectedLanguage={selectedLanguage} handleChange={handleChange} errors={errors} />

                <InitialMessageSession selectedLanguage={selectedLanguage} handleChange={handleChange} errors={errors} />

                <div className="connect-chat-widget__landing-page__footer">
                    <button id="startChat" className="connect-chat-widget__action-button" type="submit">{selectedLanguage.buttonStartChatLabel}</button>
                </div>
            </form>
        </div>
    )
}

export default Landing

function CustomUserAttribute2Session(props) {
    let selectedLanguage = props.selectedLanguage;
    if (selectedLanguage.inputCustomAttribute2Enabled) {
        return (
            <div className="connect-chat-widget__landing-page__grid-container">
                <div className="connect-chat-widget__landing-page__grid-item custom-user-attribute2">
                    <label id="lableCustomUserAttribute2">{selectedLanguage.inputCustomAttribute2Label}:</label><span
                        className="required custom2-required">*</span>
                </div>
                <div className="connect-chat-widget__landing-page__grid-item custom-user-attribute2">
                    <input className="input-tab input-full-width" name="customUserAttribute2" type="text" id="customUserAttribute2" onChange={props.handleChange}
                        placeholder={selectedLanguage.inputCustomAttribute2Placeholder} />
                </div>
            </div>
        )
    }
    return '';
}

function CustomUserAttribute3Session(props) {
    let selectedLanguage = props.selectedLanguage;
    if (selectedLanguage.inputCustomAttribute3Enabled) {
        return (
            <div className="connect-chat-widget__landing-page__grid-container">
                <div className="connect-chat-widget__landing-page__grid-item custom-user-attribute3">
                    <label id="lableCustomUserAttribute3">{selectedLanguage.inputCustomAttribute3Label}:</label><span
                        className="required custom3-required">(*)</span>
                </div>
                <div className="connect-chat-widget__landing-page__grid-item custom-user-attribute3">
                    <input className="input-tab input-full-width" name="customUserAttribute3" type="text" id="customUserAttribute3" onChange={props.handleChange}
                        placeholder={selectedLanguage.inputCustomAttribute3Placeholder} />
                </div>
            </div>
        )
    }
    return '';
}

function CustomUserAttribute4Session(props) {
    let selectedLanguage = props.selectedLanguage;
    if (selectedLanguage.inputCustomAttribute4Enabled) {
        return (
            <div className="connect-chat-widget__landing-page__grid-container">
                <div className="connect-chat-widget__landing-page__grid-item custom-user-attribute4">
                    <label id="lableCustomUserAttribute4">{selectedLanguage.inputCustomAttribute4Label}:</label>(<span
                        className="required custom4-required">*</span>)
                </div>
                <div className="connect-chat-widget__landing-page__grid-item custom-user-attribute4">
                    <select id="customUserAttribute4" name="customUserAttribute4" className="connect-chat-widget__landing-page__select-drop-down" onChange={props.handleChange}>
                        {props.renderDropDownOptions}
                    </select>
                </div>
            </div>
        )
    }
    return '';
}

function InitialMessageSession(props) {
    let selectedLanguage = props.selectedLanguage;
    if (selectedLanguage.inputInitialMessageEnabled) {
        return (
            <div className="connect-chat-widget__landing-page__grid-container">
                <div className="connect-chat-widget__landing-page__grid-item initial-message-attribute">
                    <label id="labelInitialMessage">{selectedLanguage.inputInitialMessageLabel}:</label>(<span
                        className="required initial-message-required">*</span>)
                </div>
                <div className="connect-chat-widget__landing-page__grid-item initial-message-attribute">
                    <textarea rows="5" className={classNames("connect-chat-widget__landing-page__input-area", props.errors.initialMessage ? "error-field" : "")} name="initialMessage" type="text" id="initialMessage" onChange={props.handleChange}
                        placeholder={selectedLanguage.inputInitalMessagePlaceholder}></textarea>
                    {props.errors.initialMessage && (<p className="error-text">{props.errors.initialMessage ? props.errors.initialMessage : ''}</p>)}
                </div>
            </div>
        )
    }
    return '';
}