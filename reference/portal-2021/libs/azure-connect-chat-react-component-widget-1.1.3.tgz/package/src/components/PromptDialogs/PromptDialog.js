import React from 'react';

import './PromptDialog.css';

const PromptDialog = (props) => {
    const WEB_UI_CONFIG = props.WEB_UI_CONFIG;
    const PROMPT_PAGE_CONFIG = WEB_UI_CONFIG.promptPageConfig;
    const PAGE_CONFIG = WEB_UI_CONFIG.pageConfig;

    const handleUserSelect = (params) => {
        props.handlePromptActionButtonClick(params);
    }

    const PromptPageConfigBasedOnChatLanguage = {
        headerTitle: PROMPT_PAGE_CONFIG.headerTitle.textList.find(headerTitle => headerTitle.languageIdRef === (props.chatLanguage ? props.chatLanguage
            : WEB_UI_CONFIG.languageConfig.defaultLanguageIdRef)).text,
        promptActionText: PROMPT_PAGE_CONFIG.promptActionText.textList.find(promptActionText => promptActionText.languageIdRef === (props.chatLanguage ? props.chatLanguage
            : WEB_UI_CONFIG.languageConfig.defaultLanguageIdRef)).text,
    };

    return (
        <div className="connect-chat-widget__prompt connect-chat-widget__prompt-box">
            <div className="connect-chat-widget__prompt-container">
                <div className="connect-chat-widget__prompt-header">
                    <h3 className="connect-chat-widget__prompt-header_text">{PromptPageConfigBasedOnChatLanguage.headerTitle}</h3>
                </div>
                <div className="connect-chat-widget__prompt-action">
                    <button className="connect-chat-widget__prompt-action_button connect-chat-widget__prompt-action_yes" onClick={(e) => handleUserSelect(PAGE_CONFIG.promptValue.YES)}>
                        {PromptPageConfigBasedOnChatLanguage.promptActionText.YES}
                    </button>
                    <button className="connect-chat-widget__prompt-action_button connect-chat-widget__prompt-action_no" onClick={(e) => handleUserSelect(PAGE_CONFIG.promptValue.NO)}>
                        {PromptPageConfigBasedOnChatLanguage.promptActionText.NO}
                    </button>
                </div>
            </div>
        </div>
    )
}

export default PromptDialog
