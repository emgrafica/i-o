
import './fabric-icons-inline.css';
import './ConnectChatWidget.css';
import './custom-styles.css';
import AppSeting from '../../../appsetting.json';
import classNames from 'classnames';
import React, { useCallback, useMemo, useState, useEffect } from 'react';
import { createStore } from 'botframework-webchat';
import WebChat from '../WebChats/WebChat';
import Landing from '../Landings/Landing';
import PromptDialog from '../PromptDialogs/PromptDialog';
import * as UI_CONFIG from '../../constants/WebUiConfigModel';
import PropTypes from 'prop-types';
import useScript from '../../hooks/useScript';
import createInitialName from '../../hooks/createInitialName';

export const ConnectChatWidget = ({
  userFirstName,
  userEmail,
  userLanguage,
  soundNotificationUrl,
  headerLogoUrl,
  minimizedFromOutSide,
  secretKey,
  configFileUrl
}) => {
  // Load and add script to DOM
  const [isScriptLoaded, setIsScriptLoaded] = useState(false);
  if (configFileUrl) {
    useScript(configFileUrl, setIsScriptLoaded);
  }
  const [WEB_UI_CONFIG, SET_WEB_UI_CONFIG] = useState(UI_CONFIG.WEB_UI_CONFIG);
  const [PAGE_CONFIG, SET_PAGE_CONFIG] = useState(WEB_UI_CONFIG.pageConfig);
  const [CHAT_UI_CONFIG, SET_CHAT_UI_CONFIG] = useState(WEB_UI_CONFIG.chatUiConfig);
  useEffect(() => {
    if (isScriptLoaded) {
      // If have external script url, change the WEB_UI_CONFIG to WEB_UI_CONFIG_EXTERNAL
      SET_WEB_UI_CONFIG(WEB_UI_CONFIG_EXTERNAL);
      SET_PAGE_CONFIG(WEB_UI_CONFIG.pageConfig);
      SET_CHAT_UI_CONFIG(WEB_UI_CONFIG.chatUiConfig);
    }
  }, [isScriptLoaded]);

  const DEFAULT_WAIT_TIME_OUT = 5000; //milisecond
  // Config file 
  const notificationSound = new Audio(soundNotificationUrl);
  // const WEB_UI_CONFIG = WEB_UI_CONFIG_EXTERNAL ? WEB_UI_CONFIG_EXTERNAL : UI_CONFIG.WEB_UI_CONFIG;
  // The info that need to start the converstation include:
  // firstName, emailId, chatLanguage, customerattributes, initial message
  const [initChatInfo, setInitChatInfo] = useState();
  const [loaded, setLoaded] = useState(false);
  const [minimized, setMinimized] = useState(true);
  const [newMessage, setNewMessage] = useState(false);
  const [token, setToken] = useState();
  // Old conversation information if it exist
  const [oldConversation, setOldConversation] = useState({
    id: localStorage.getItem('conversationId'),
    timeRange: localStorage.getItem('conversationTimeStamp') ? parseInt(new Date().getTime()) - parseInt(localStorage.getItem('conversationTimeStamp')) : null,
    chatLanguage: localStorage.getItem('conversationLanguage'),
  });
  // The information that needed to reconect to the old conversation
  const [reconnect, setReconnect] = useState({
    hasOldConversation: oldConversation !== undefined ? true : false,
    reconnectMethod: oldConversation === undefined ? PAGE_CONFIG.reconnectMethod.NEW_CONVERSATION.text
      : (parseInt(oldConversation.timeRange) <= parseInt(PAGE_CONFIG.reconnectMethod.AUTO.timeframe) ? PAGE_CONFIG.reconnectMethod.AUTO.text
        : (parseInt(oldConversation.timeRange) <= parseInt(PAGE_CONFIG.reconnectMethod.PROMT_TO_USER.timeframe) ? PAGE_CONFIG.reconnectMethod.PROMT_TO_USER.text
          : PAGE_CONFIG.reconnectMethod.NEW_CONVERSATION.text))
  });
  // When the reconnect method is "PROMT_TO_USER" this state is used for the option
  // that selected by user
  const [userPromptSelected, setUserPromptSelected] = useState();

  // The time range that end chat is in process
  const [endChatInProcess, setEndChatInProcess] = useState(false);

  // When user start the "Start chat" btn, this state is true
  const [chatStarted, setChatStarted] = useState(false);

  // If user want to create new session or not
  const [requestNewSession, setRequestNewSession] = useState(false);
  const [tokenExpired, setTokenExpired] = useState();
  const defaultAvatarInitial = {
    displayAvatar: CHAT_UI_CONFIG.displayAvatar,
    botAvatarInitials: CHAT_UI_CONFIG.botAvatarInitials,
    userAvatarInitials: createInitialName(userFirstName),
    avatarStyle: {
      botAvatarColor: CHAT_UI_CONFIG.avatarStyle.botAvatarColor,
      botAvatarBackgroundColor: CHAT_UI_CONFIG.avatarStyle.botAvatarBackgroundColor,
      userAvatarcolor: CHAT_UI_CONFIG.avatarStyle.userAvatarcolor,
      userAvatarBackgroundColor: CHAT_UI_CONFIG.avatarStyle.userAvatarBackgroundColor
    }
  };
  const [avatarInitial, setAvatarInitial] = useState(defaultAvatarInitial);
  const store = useMemo(
    () =>
      createStore({}, ({ dispatch }) => next => action => {
        if (action.type === 'DIRECT_LINE/CONNECT_FULFILLED') {
          dispatch({
            type: 'WEB_CHAT/SEND_EVENT',
            payload: {
              name: 'webchat/join',
              value: {
                language: window.navigator.language,
                data: initChatInfo,
                requestNewSession: requestNewSession
              }
            }
          });
        } else if (action.type === 'DIRECT_LINE/INCOMING_ACTIVITY') {
          if (action.payload.activity.from.role === 'bot') {
            setNewMessage(true);
            playNotificationSound();
          }
          if (action.payload.activity.text === AppSeting.agentLeftAction) {
            startEndChatProcess();
          }
          if (action.payload.activity.text === AppSeting.sessionAlreadyCloseAction) {
            startEndChatProcess();
          }
          if (action.payload.activity.text === AppSeting.invalidUserProfileAction) {
            startEndChatProcess();
            window.alert("Has an error occurred, please refresh page and try again.");
          }
          if (action.payload.activity.channelData && action.payload.activity.channelData.type && action.payload.activity.channelData.type === "connectAgent") {
            handleAgentEnteredConversation(action.payload.activity.channelData);
          }
        }
        return next(action);
      }),
    [initChatInfo, requestNewSession]
  );

  const disconnectStore = useMemo(
    () =>
      createStore({}, ({ dispatch }) => next => action => {
        if (action.type === 'DIRECT_LINE/CONNECT_FULFILLED') {
          dispatch({
            type: 'WEB_CHAT/SEND_EVENT',
            payload: {
              name: 'webchat/join',
              value: {
                language: window.navigator.language,
                data: initChatInfo,
                requestNewSession: false
              }
            }
          });
          dispatch({
            type: 'WEB_CHAT/SET_SEND_BOX',
            payload: { text: AppSeting.endChatAction }
          });
          dispatch({
            type: 'WEB_CHAT/SUBMIT_SEND_BOX',
            payload: { text: 'keyboard' }
          });
        } else if (action.type === 'DIRECT_LINE/INCOMING_ACTIVITY') {
          if (action.payload.activity.text === AppSeting.agentLeftAction) {
            startEndChatProcess();
          }
          if (action.payload.activity.text === AppSeting.sessionAlreadyCloseAction) {
            startEndChatProcess();
          }
          if (action.payload.activity.text === AppSeting.invalidUserProfileAction) {
            startEndChatProcess();
            window.alert("Has an error occurred, please refresh page and try again.");
          }
        }
        return next(action);
      }),
    [initChatInfo, requestNewSession]
  );

  const handleFetchToken = useCallback(async () => {
    // If the old converstation id is exist
    // Reconnect to the old conversation
    if (oldConversation.id === null && chatStarted === true) {
      if (!token) {
        setRequestNewSession(true);
        await fetch('https://directline.botframework.com/v3/directline/tokens/generate', {
          method: 'POST',
          headers: {
            Authorization: 'Bearer ' + secretKey
          }
        }).then(async response => {
          if (response.ok) {
            response = await response.json();
            // save converstation to local storage to reconnect purpose
            localStorage.setItem('conversationId', response.conversationId);
            localStorage.setItem('conversationTimeStamp', new Date().getTime());
            if (response.token) {
              setToken(response.token);
              setTokenExpired(response.expires_in);
            }
          }
        }).catch(err => {
          console.log("Have some error occur, please try again!");
        });
      }
    }
    else {
      if (oldConversation.id !== null) {
        setRequestNewSession(false);
        await fetch(`https://directline.botframework.com/v3/directline/conversations/${oldConversation.id}`, {
          method: 'GET',
          headers: {
            Authorization: 'Bearer ' + secretKey
          }
        }).then(async response => {
          if (response.ok) {
            response = await response.json();
            localStorage.setItem('conversationId', response.conversationId);
            localStorage.setItem('conversationTimeStamp', new Date().getTime());
            if (response.token) {
              setToken(response.token);
              setTokenExpired(response.expires_in);
            }
          }
        }).catch(err => {
          console.log("Have some error occur, please try again!");
        });
      }
    }
  }, [setToken, token, chatStarted, setChatStarted, userPromptSelected, setUserPromptSelected]);

  const handleMaximizeButtonClick = useCallback(async () => {
    setLoaded(true);
    setMinimized(false);
    setNewMessage(false);
  }, [setMinimized, setNewMessage]);

  const handleMinimizeButtonClick = useCallback(() => {
    setMinimized(true);
    setNewMessage(false);
  }, [setMinimized, setNewMessage]);

  const playNotificationSound = () => {
    notificationSound.play();
  }

  const handleEndChatButtonClick = useCallback(async () => {
    if (token) {
      store.dispatch({
        type: 'WEB_CHAT/SET_SEND_BOX',
        payload: { text: AppSeting.endChatAction }
      });
      store.dispatch({
        type: 'WEB_CHAT/SUBMIT_SEND_BOX',
        payload: { text: 'keyboard' }
      });
    }
    startEndChatWaiter(DEFAULT_WAIT_TIME_OUT);
  });

  // Set value to default and return to the landing page
  const startEndChatProcess = () => {
    setOldConversation({
      id: null,
      timeRange: null,
      chatLanguage: null
    });
    setInitChatInfo(undefined);
    setChatStarted(false);
    setToken();
    setEndChatInProcess(false);
    clearConversationInfo();
    setUserPromptSelected();
    setReconnect({
      hasOldConversation: false,
      reconnectMethod: PAGE_CONFIG.reconnectMethod.NEW_CONVERSATION.text
    });
    // Minimized chat after end chat
    setMinimized(true);
    setNewMessage(false);
    setAvatarInitial(defaultAvatarInitial);
  }

  const handlePromptActionButtonClick = useCallback(async (value) => {
    if (value === PAGE_CONFIG.promptValue.YES) {
      // User click yes
      setUserPromptSelected(value);
      setChatStarted(true);
    } else {
      // User click no
      setUserPromptSelected(value);
      startEndChatWaiter(DEFAULT_WAIT_TIME_OUT);
    }
  }, [userPromptSelected, setUserPromptSelected, token, setToken]);

  const clearConversationInfo = () => {
    localStorage.removeItem('conversationId');
    localStorage.removeItem('conversationTimeStamp');
    localStorage.removeItem('conversationLanguage');
  };

  const startEndChatWaiter = (waitingTimeout) => {
    // This function is the waiter for end chat progress
    setEndChatInProcess(true);
    setTimeout(() => {
      // If endChat process is false and chat Started is true
      // that mean in 5s, Component doesn't receive the "endchat" signal from Control Layer
      // Force end chat
      startEndChatProcess();
    }, waitingTimeout);
  };

  const handleAgentEnteredConversation = (channelData) => {
    let prevAvatarInitial = Object.assign({}, avatarInitial);
    prevAvatarInitial['botAvatarInitials'] = createInitialName(channelData.data.agentName);
    setAvatarInitial(prevAvatarInitial);
  }

  // If init chat info still is undefine, not start the chat
  useEffect(() => {
    if (reconnect.reconnectMethod === PAGE_CONFIG.reconnectMethod.NEW_CONVERSATION.text) {
      setOldConversation({
        id: null,
        timeRange: null,
        chatLanguage: null
      });
      clearConversationInfo();
    }
    if (initChatInfo !== undefined) {
      setChatStarted(true);
      localStorage.setItem("conversationLanguage", initChatInfo.languageId);
    }
  }, [initChatInfo]);

  useEffect(() => {
    if (tokenExpired) {
      // Auto refresh token
      let interval = setInterval(async () => {
        await fetch(`https://directline.botframework.com/v3/directline/tokens/refresh`, {
          method: 'POST',
          headers: {
            Authorization: 'Bearer ' + token
          }
        }).then(async response => {
          if (response.ok) {
            response = await response.json();
            if (response.token) {
              setToken(response.token);
              setTokenExpired(response.expires_in);
            }
          }
        }).catch(err => {
          console.log("Refresh token has an error!");
        });
      },
        (parseInt(tokenExpired) * 1000) - 100);
      //destroy interval on unmount
      return () => clearInterval(interval)
    }
  })

  useEffect(() => {
    if (!minimizedFromOutSide) {
      setLoaded(true);
      setMinimized(false);
      setNewMessage(false);
    }
    else {
      setMinimized(true);
      setNewMessage(false);
    }
  }, [minimizedFromOutSide]);

  return (
    <div className="connect-chat-widget">
      {minimized && (
        <button className="connect-chat-widget__maximize-button" onClick={handleMaximizeButtonClick} title="Maximize chat window">
          <span className={token ? 'ms-Icon ms-Icon--MessageFill' : 'ms-Icon ms-Icon--Message'} />
          {newMessage && <span className="ms-Icon ms-Icon--CircleShapeSolid red-dot" />}
        </button>
      )}
      {!minimized && (
        <button className="connect-chat-widget__maximize-button close" onClick={handleMinimizeButtonClick} title="Minimize chat window">
          <span className='ms-Icon ms-Icon--ChromeMinimize' />
        </button>
      )}
      {loaded && (
        <div className={classNames('connect-chat-widget__chat-box right', minimized ? 'hide' : '')}>
          <header className="connect-chat-widget__header">
            <div className="connect-chat-widget__header--container">
              <div className="connect-chat-widget__header--logo">
                <img className="logo" src={headerLogoUrl} />
              </div>
              <div className="connect-chat-widget__header--title">
                <p className="connect-chat-widget__header--title-text">You are now chatting with IT Support</p>
              </div>
            </div>
          </header>
          {(chatStarted ||
            reconnect.reconnectMethod === PAGE_CONFIG.reconnectMethod.AUTO.text ||
            (userPromptSelected ? userPromptSelected : false) === PAGE_CONFIG.promptValue.YES) && (
              <WebChat
                className="react-web-chat"
                onFetchToken={handleFetchToken}
                store={store}
                token={token}
                avatarInitial={avatarInitial} />
            )}
          {((userPromptSelected ? userPromptSelected : false) === PAGE_CONFIG.promptValue.NO) && (
            <WebChat
              className="react-web-chat"
              onFetchToken={handleFetchToken}
              store={disconnectStore}
              token={token}
              endConversation={true} />
          )}
          {(chatStarted ||
            reconnect.reconnectMethod === PAGE_CONFIG.reconnectMethod.AUTO.text ||
            (userPromptSelected ? userPromptSelected : false) === PAGE_CONFIG.promptValue.YES) && (
              <footer className="connect-chat-widget__footer">
                <button
                  className="connect-chat-widget__action-button button-end-chat"
                  onClick={handleEndChatButtonClick}
                  disabled={endChatInProcess}>
                  End Chat
                </button>
              </footer>
            )}
          {(!chatStarted && reconnect.reconnectMethod === PAGE_CONFIG.reconnectMethod.NEW_CONVERSATION.text) && (
            <Landing
              setInitChatInfo={setInitChatInfo}
              userFirstName={userFirstName}
              userEmail={userEmail}
              userLanguage={userLanguage}
              WEB_UI_CONFIG={WEB_UI_CONFIG} />
          )}
          {(reconnect.hasOldConversation === true
            && reconnect.reconnectMethod === PAGE_CONFIG.reconnectMethod.PROMT_TO_USER.text
            && userPromptSelected === undefined)
            && (
              <PromptDialog
                handlePromptActionButtonClick={handlePromptActionButtonClick}
                chatLanguage={oldConversation.chatLanguage}
                WEB_UI_CONFIG={WEB_UI_CONFIG} />
            )}
        </div>
      )}
    </div>
  );
};

ConnectChatWidget.propTypes = {
  userFirstName: PropTypes.string.isRequired,
  userEmail: PropTypes.string.isRequired,
  userLanguage: PropTypes.string.isRequired,
  soundNotificationUrl: PropTypes.string,
  headerLogoUrl: PropTypes.string.isRequired,
  minimizedFromOutSide: PropTypes.bool,
  secretKey: PropTypes.string.isRequired,
  configFileUrl: PropTypes.string,
}