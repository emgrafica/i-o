import React, { useEffect, useMemo } from 'react';
import ReactWebChat, { createDirectLine, createStyleSet } from 'botframework-webchat';

import './WebChat.css';

const WebChat = ({
  className,
  onFetchToken,
  store,
  token,
  endConversation,
  avatarInitial
}) => {
  const directLine = useMemo(() => createDirectLine({ token }), [token]);
  const styleSet = useMemo(
    () =>
      createStyleSet({

        backgroundColor: 'Transparent',
        bubbleMaxWidth: '90%',
      }),
    []
  );

  styleSet.avatar = {
    ...styleSet.avatar,
    '.webchat__initialsAvatar--fromUser': {
      'background-color': avatarInitial.avatarStyle.userAvatarBackgroundColor + ' !important',
      'color': avatarInitial.avatarStyle.userAvatarcolor + ' !important'
    },
    '.webchat__initialsAvatar:not(.webchat__initialsAvatar--fromUser)': {
      'background-color': avatarInitial.avatarStyle.botAvatarBackgroundColor + ' !important',
      'color': avatarInitial.avatarStyle.botAvatarColor + ' !important'
    }
  }

  const styleOptions = {
    botAvatarInitials: avatarInitial.displayAvatar ? avatarInitial.botAvatarInitials : null,
    userAvatarInitials: avatarInitial.displayAvatar ? avatarInitial.userAvatarInitials : null,
    groupTimestamp: 3000,
    showAvatarInGroup: 'timestamp'

  };

  useEffect(() => {
    onFetchToken();
  }, [onFetchToken]);

  return (endConversation === true) ? (<div className={`${className || ''} connect-spinner`}>
    <div className="content">
      <p>Please wait while we are closing the previous conversation.</p>
      <ReactWebChat className={`${className || ''} web-chat hide-react-web-chat`}
        directLine={directLine}
        store={store}
        styleSet={styleSet}
        styleOptions={styleOptions} />
    </div>
  </div>) : (token ? (
    <ReactWebChat className={`${className || ''} web-chat`}
      directLine={directLine}
      store={store}
      styleSet={styleSet}
      styleOptions={styleOptions} />
  ) : (
    <div className={`${className || ''} connect-spinner`}>
      <div className="content">
        <p>Please wait while we are connecting.</p>
      </div>
    </div>
  ));
};

export default WebChat;