export default function validateInfomation(values) {
    if (values) {
        let isValid = true;
        if (!values.chatLanguage) {
            isValid = false;
        }
        if (!values.firstName) {
            isValid = false;
        }
        if (!values.emailId) {
            isValid = false;
        }
        if (!values.customUserAttribute2) {
            isValid = false;
        }
        if (!values.customUserAttribute4) {
            isValid = false;
        }
        if (!values.customUserAttribute4) {
            isValid = false;
        }
        return isValid;
    }
    else {
        return false;
    }
}