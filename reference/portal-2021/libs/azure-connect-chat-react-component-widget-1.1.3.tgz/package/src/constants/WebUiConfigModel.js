export const WEB_UI_CONFIG = {
    languageConfig: {
        supportedLanguages:
            [
                {
                    languageId: "English",
                    languageCode: "en-US",
                    sourceIdRef: "AMR_Region"
                },
                {
                    languageId: "French",
                    languageCode: "fr-FR",
                    sourceIdRef: "NCESE_Region"
                },
                {
                    languageId: "Italian",
                    languageCode: "it-IT",
                    sourceIdRef: "NCESE_Region"
                }
            ],
        defaultLanguageIdRef: "English"
    },

    sourceConfig: {
        sourceList:
            [
                {
                    sourceId: "AMR_Region",
                    chatSourceName: "ConnectChat_Philips_AMR",
                    apiGatewayEndpoing: "https://w9axnkvtze.execute-api.eu-central-1.amazonaws.com/prod/ASD-Customer-Chat",
                    region: "eu-central-1"
                },
                {
                    sourceId: "NCESE_Region",
                    chatSourceName: "ConnectChat_Philips_NCESE",
                    apiGatewayEndpoing: "https://w9axnkvtze.execute-api.eu-central-1.amazonaws.com/prod/ASD-Customer-Chat",
                    region: "eu-central-1"
                }
            ]
    },

    landingConfig: {
        hideLandingOnStart: false,
        pageTitle: {
            textList:
                [
                    { languageIdRef: "English", text: "Philips IT Support Portal" },
                    { languageIdRef: "French", text: "Le Portal de Philips de IT" },
                    { languageIdRef: "Italian", text: "Title in Italiano" }
                ]
        },
        landingHeaderAnnouncement: {
            textList:
                [
                    { languageIdRef: "English", text: "You are now chatting with IT Support" },
                    { languageIdRef: "French", text: "Vous discutez maintenant avec le support informatique" },
                    { languageIdRef: "Italian", text: "Stai chattando con il supporto IT" }
                ]
        },
        landingHeaderTitle: {
            textList:
                [
                    { languageIdRef: "English", text: "Contact Us" },
                    { languageIdRef: "French", text: "Nous contacter" },
                    { languageIdRef: "Italian", text: "Contattaci" }
                ]
        },
        landingHeaderTitleText: {
            textList:
                [
                    { languageIdRef: "English", text: "Thank you for reaching to us. Please fill out the form below and we will direct you to the appropriate support team member!" },
                    { languageIdRef: "French", text: "Merci de nous avoir rejoint. Veuillez remplir le formulaire ci-dessous et nous vous dirigerons vers le membre de l'équipe d'assistance approprié !" },
                    { languageIdRef: "Italian", text: "Grazie per averci raggiunto. Compila il modulo sottostante e ti indirizzeremo al membro del team di supporto appropriato!" }
                ]
        },
        missingRequirementFieldError: {
            textList:
                [
                    { languageIdRef: "English", text: "Missing some required field, please try again." },
                    { languageIdRef: "French", text: "Il manque un champ obligatoire, veuillez réessayer." },
                    { languageIdRef: "Italian", text: "Manca qualche campo obbligatorio, per favore riprova." }
                ]
        },
        inputLanguageOptionText: {
            textList:
                [
                    { languageIdRef: "English", text: "English" },
                    { languageIdRef: "French", text: "Français" },
                    { languageIdRef: "Italian", text: "Italiano" }
                ]
        },
        inputlanguageLabel: {
            textList:
                [
                    { languageIdRef: "English", text: "Lanaguage" },
                    { languageIdRef: "French", text: "Langue" },
                    { languageIdRef: "Italian", text: "Linguaggio" }
                ]
        },

        inputFirstNameEnabled: true,
        inputFirstNameLabel: {
            textList:
                [
                    { languageIdRef: "English", text: "First name" },
                    { languageIdRef: "French", text: "Prénom" },
                    { languageIdRef: "Italian", text: "Nome di battesimo" }
                ]
        },
        inputFirstNamePlaceholder: {
            textList:
                [
                    { languageIdRef: "English", text: "First name" },
                    { languageIdRef: "French", text: "Prénom" },
                    { languageIdRef: "Italian", text: "Nome di battesimo" }
                ]
        },

        inputEmailEnabled: true,
        inputEmailLabel: {
            textList:
                [
                    { languageIdRef: "English", text: "Email" },
                    { languageIdRef: "French", text: "E-mail" },
                    { languageIdRef: "Italian", text: "E-mail" }
                ]
        },
        inputEmailPlaceholder: {
            textList:
                [
                    { languageIdRef: "English", text: "Email" },
                    { languageIdRef: "French", text: "E-mail" },
                    { languageIdRef: "Italian", text: "E-mail" }
                ]
        },

        inputCustomAttribute2Enabled: false,
        inputCustomAttribute2Label: {
            textList:
                [
                    { languageIdRef: "English", text: "Custom Attribute 2" },
                    { languageIdRef: "French", text: "Attribut personnalisé 2" },
                    { languageIdRef: "Italian", text: "Attributo personalizzato 2" }
                ]
        },
        inputCustomAttribute2Placeholder: {
            textList:
                [
                    { languageIdRef: "English", text: "Custom Attribute 2" },
                    { languageIdRef: "French", text: "Attribut personnalisé 2" },
                    { languageIdRef: "Italian", text: "Attributo personalizzato 2" }
                ]
        },

        inputCustomAttribute3Enabled: false,
        inputCustomAttribute3Label: {
            textList:
                [
                    { languageIdRef: "English", text: "Custom Attribute 3" },
                    { languageIdRef: "French", text: "Attribut personnalisé 3" },
                    { languageIdRef: "Italian", text: "Attributo personalizzato 3" }
                ]
        },
        inputCustomAttribute3Placeholder: {
            textList:
                [
                    { languageIdRef: "English", text: "Custom Attribute 3" },
                    { languageIdRef: "French", text: "Attribut personnalisé 3" },
                    { languageIdRef: "Italian", text: "Attributo personalizzato 3" }
                ]
        },

        inputCustomAttribute4Enabled: true,
        inputCustomAttribute4Label: {
            textList:
                [
                    { languageIdRef: "English", text: "Problem Type" },
                    { languageIdRef: "French", text: "Attribut personnalisé 4" },
                    { languageIdRef: "Italian", text: "Attributo personalizzato 4" }
                ]
        },
        inputCustomAttribute4Options:
            [
                {
                    optionText: {
                        textList:
                            [
                                { languageIdRef: "English", text: "All password and access" },
                                { languageIdRef: "French", text: "Tous les mots de passe et accès" },
                                { languageIdRef: "Italian", text: "Tutte le password e gli accessi" }
                            ]
                    },
                    value: "password"
                },
                {
                    optionText: {
                        textList:
                            [
                                { languageIdRef: "English", text: "Office Suite and Windows" },
                                { languageIdRef: "French", text: "Suite Office et Windows" },
                                { languageIdRef: "Italian", text: "Suite Office e Windows" }
                            ]
                    },
                    value: "windows"
                },
                {
                    optionText: {
                        textList:
                            [
                                { languageIdRef: "English", text: "Hardware" },
                                { languageIdRef: "French", text: "Matériel" },
                                { languageIdRef: "Italian", text: "Hardware" }
                            ]
                    },
                    value: "hardware"
                },
                {
                    optionText: {
                        textList:
                            [
                                { languageIdRef: "English", text: "Business Solutions (CICS,SAP,Pivotal,Aspen)" },
                                { languageIdRef: "French", text: "Solutions d'affaires (CICS, SAP, Pivotal, Aspen)" },
                                { languageIdRef: "Italian", text: "Soluzioni aziendali (CICS, SAP, Pivotal, Aspen)" }
                            ]
                    },
                    value: "business"
                },
                {
                    optionText: {
                        textList:
                            [
                                { languageIdRef: "English", text: "Other" },
                                { languageIdRef: "French", text: "Autre" },
                                { languageIdRef: "Italian", text: "Altro/Altra" }
                            ]
                    },
                    value: "general"
                }
            ],

        inputInitialMessageEnabled: true,
        inputInitialMessageLabel: {
            textList:
                [
                    { languageIdRef: "English", text: "Briefly describe the help you need" },
                    { languageIdRef: "French", text: "Message initial" },
                    { languageIdRef: "Italian", text: "Messaggio iniziale" }
                ]
        },
        inputInitalMessagePlaceholder: {
            textList:
                [
                    { languageIdRef: "English", text: "Describe" },
                    { languageIdRef: "French", text: "Message initial" },
                    { languageIdRef: "Italian", text: "Messaggio iniziale" }
                ]
        },

        buttonStartChatLabel: {
            textList:
                [
                    { languageIdRef: "English", text: "Start chat" },
                    { languageIdRef: "French", text: "Démarrer la discussion" },
                    { languageIdRef: "Italian", text: "Inizia chat" }
                ]
        },

        messageErrorOccurred: {
            textList:
                [
                    { languageIdRef: "English", text: "ERROR OCCURRED" },
                    { languageIdRef: "French", text: "ERREUR EST SURVENUE" },
                    { languageIdRef: "Italian", text: "ERRORE" }
                ]
        },
        messageErrorPleaseEnter: {
            textList:
                [
                    { languageIdRef: "English", text: "Please enter this field" },
                    { languageIdRef: "French", text: "Veuillez saisir ce champ" },
                    { languageIdRef: "Italian", text: "Si prega di inserire questo campo" }
                ]
        },
        messageErrorInitChat: {
            textList:
                [
                    { languageIdRef: "English", text: "Please enter this fieldThere was a problem initiating the chat. Please try again later." },
                    { languageIdRef: "French", text: "Un problème est survenu lors du lancement du chat. Veuillez réessayer plus tard." },
                    { languageIdRef: "Italian", text: "Si è verificato un problema durante l'avvio della chat. Per favore riprova più tardi." }
                ]
        }
    },

    chatUiConfig: {
        headerTitle: {
            textList:
                [
                    { languageIdRef: "English", text: "Chat Demo" },
                    { languageIdRef: "French", text: "Démo de discussion" },
                    { languageIdRef: "Italian", text: "Dimostrazione chat" }
                ]
        }, //Map to "header"
        headerMessage: {
            textList:
                [
                    { languageIdRef: "English", text: "This is a demo of a customer chat experience" },
                    { languageIdRef: "French", text: "Ceci est une démonstration d'une expérience de chat client" },
                    { languageIdRef: "Italian", text: "Questa è una demo di un'esperienza di chat con i clienti" }
                ]
        }, //Map to "headerWelcome"
        headerHtml: "<html stuff here>",

        messageChatWith: {/*Text Obj*/ },
        messageHasJoinedTheChat: {/*Text Obj*/ },
        messageHasLeftTheChat: {/*Text Obj*/ },
        messageChatHasEnded: {/*Text Obj*/ },
        messageLoadingPreviousMessage: {/*Text Obj*/ },
        messageSystemMessage: {/*Text Obj*/ },
        messageTypeAMessage: {/*Text Obj*/ },
        messageSentAt: {/*Text Obj*/ },
        messagesendingAt: {/*Text Obj*/ },

        buttonEndChatLabel: {/*Text Obj*/ },
        buttonEndChatImgUrl: "./Images/button_terminate.gif",
        buttonSendEnabled: true,
        buttonSendImgUrl: "./Images/button_send.gif",
        canSendByPressingEnter: true,
        displayAvatar: true,
        botAvatarInitials: "Bot",
        avatarStyle: {
            botAvatarColor: 'white',
            botAvatarBackgroundColor: '#5f249f',
            userAvatarcolor: 'white',
            userAvatarBackgroundColor: '#5f249f'
        }
    },
    promptPageConfig: {
        headerTitle: {
            textList:
                [
                    { languageIdRef: "English", text: "Do you want to reconnect the previous conversation?" },
                    { languageIdRef: "French", text: "Voulez-vous reconnecter la conversation précédente ?" },
                    { languageIdRef: "Italian", text: "Vuoi ricollegare la conversazione precedente?" }
                ]
        },
        promptActionText: {
            textList:
                [
                    {
                        languageIdRef: "English", text: {
                            YES: "Yes",
                            NO: "No"
                        }
                    },
                    {
                        languageIdRef: "French", text: {
                            YES: "Oui",
                            NO: "Non"
                        }
                    },
                    {
                        languageIdRef: "Italian", text: {
                            YES: "Sì",
                            NO: "No"
                        }
                    }
                ]
        }
    },
    pageConfig: {
        sourcePlatform: "EUA",
        noIEMessage: "This site does not support Internet Explorer.",
        autoStart: false,
        notificationSoundEnable: true,
        reconnectMethod: {
            AUTO: {
                text: "AUTO",
                timeframe: "900000"
            },
            PROMT_TO_USER: {
                text: "PROMT_TO_USER",
                timeframe: "18900000"
            },
            NEW_CONVERSATION: {
                text: "NEW_CONVERSATION",
                timeframe: null
            }
        },
        promptValue: {
            YES: "YES",
            NO: "NO"
        }
    },
    componentUIConfig: {
        minimizeToolTip: {
            textList:
                [
                    { languageIdRef: "English", text: "Philips IT Support Portal" },
                    { languageIdRef: "French", text: "Le Portal de Philips de IT" },
                    { languageIdRef: "Italian", text: "Title in Italiano" }
                ]
        },
    }
}