import { ConnectChatWidget } from '../components/ConnectChatWidgets/ConnectChatWidget';
export default {
    title: 'ConnectChat Widget',
    Comment: ConnectChatWidget
}

const Template = args => <ConnectChatWidget {...args} />
export const Default = Template.bind({});
Default.args = {
    userFirstName: 'Nam Dinh',
    userEmail: 'namquang.dinh2@dxc.com',
    userLanguage: 'it-IT',
    soundNotificationUrl: 'https://www.fiftysounds.com/music/sfx-pop.mp3',
    headerLogoUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/a/a3/DXC_Technology_logo_%282021%29.svg/1280px-DXC_Technology_logo_%282021%29.svg.png',
    minimizedFromOutSide: false,
    secretKey: 'QatndxrRnHg.-KbNczfmIu4QFVA--OrTzBd7LzSNumKXvduZOsYGHP0',
    configFileUrl: '',
};